package edu.ucalgary.oop;
/**
 * @author Rohan Kapila
 * @version 1.5
 * @since 1.0
 */



import javax.swing.*;
import java.awt.*;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.*;
import java.awt.FlowLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;

public class EWRGUI extends JFrame implements ActionListener {
    private JLabel headerLabel;
    private JLabel taskLabel;
    private JLabel startLabel;
    private JLabel dateLabel;

    private JTextField taskField;
    private JTextField startField;
    private JTextField dateField;

    private JButton calcButton;

    private JTextArea schedArea;

    private JComboBox<String> taskComboBox;

    public EWRGUI() {
        // Specify the JFrame and its properties
        setTitle("Create An EWR Schedule");
        setSize(400, 100);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setBackground(Color.BLACK);


        //Set up the title and labels for buttons and inputs
        headerLabel = new JLabel("Create A Schedule", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 23));

        dateLabel = new JLabel("Date (YYYY-MM-DD):");
        dateField = new JTextField(10);

        calcButton = new JButton("Generate Schedule");
        calcButton.addActionListener(this); //add event to trigger button function



        Font buttonFont = calcButton.getFont();
        calcButton.setFont(new Font(buttonFont.getName(), buttonFont.getStyle(), 16)); // Change the size of the font to (16)


        //Create the area where the schedule will be written onto and set it so the user cannot change it
        schedArea = new JTextArea(20, 20);
        schedArea.setEditable(false);

        //Specify the inner layout and orientation of panel and its components
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(headerLabel, BorderLayout.CENTER);
        add(topPanel, BorderLayout.NORTH);

        JPanel inputPanel = new JPanel(new GridLayout(4, 2));
        inputPanel.add(dateLabel);
        inputPanel.add(dateField);
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(calcButton);
        add(inputPanel, BorderLayout.NORTH);

        add(buttonPanel, BorderLayout.WEST);

        JScrollPane scrollPane = new JScrollPane(schedArea);
        add(scrollPane, BorderLayout.CENTER);
        setVisible(true);
    }



    //this method first parses through the input date by the user to confirm if it is
    // valid, then uses it to make a schedule object to complete the method
    private String scheduleCalc(String dateStr, boolean backupVolunteerNeeded) throws IllegalArgumentException {
        try {
            LocalDate.parse(dateStr, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("Invalid date entry.");
        }

        StringBuilder sb = new StringBuilder();
        int day = Integer.parseInt(dateStr.substring(8));
        int month = Integer.parseInt(dateStr.substring(5, 7));
        int year = Integer.parseInt(dateStr.substring(0, 4));
        Schedule schedule = new Schedule(day, month, year);
        try {
            schedule.readSql();
        } catch (SQLException e) {
            e.printStackTrace();
        }


        //makeEfficientSchedule method is called, and if the tasks cannot be fit into the timeslot, they are put into the invalidTreatmentsList
        while (true) {

            try {
                schedule.makeEfficientSchedule();
                break;
            } catch (IllegalArgumentException e) {
                ArrayList<AnimalTreatments> invalidTreatmentsList = schedule.getInvalidTreatmentsList();
                int invalidIndex = schedule.getInvalidTreatmentsListIndex();

                //The values of the invalidTreatments are assigned to variables and the user is given a prompt to change the start time
                for (int index = invalidIndex; index < invalidTreatmentsList.size(); index++) {
                    int maxWindow = invalidTreatmentsList.get(index).MedicalTaskGetter().MaxWindowGetter();
                    AnimalTreatments invalidTreat = invalidTreatmentsList.get(index);

                    String medTaskDescription = invalidTreat.MedicalTaskGetter().descriptionGetter();
                    String medTaskAnimal = invalidTreat.MedicalTaskGetter().nicknameGetter();
                    String userInstructions = "Treatment Description: " + medTaskDescription
                            + "\nAnimal Treated: " + medTaskAnimal
                            + "\nCant Generate\n Enter a different Start Hour";
                    String input = JOptionPane.showInputDialog(null, userInstructions);

                    //validates through parsing if the user entered the value in the correct format
                    try {
                        LocalTime.parse(input, DateTimeFormatter.ofPattern("HH:mm"));
                        if (!input.substring(3).equals("00")) {
                            throw new IllegalArgumentException(
                                    "minute format is not correct");
                        }
                    } catch (DateTimeParseException f) {
                        throw new IllegalArgumentException(
                                "start time is invalid");
                    }
                    int startHourChosen = Integer.parseInt(input.substring(0, 2));

                    //if input passes checks and is assigned to startHourChosen variable, checks are done to see if it fits within the maxWindow
                    while (true) {
                        if (startHourChosen >= maxWindow) {
                            JOptionPane.showMessageDialog(null,
                                    "start time invalid " + maxWindow + ":00");
                        } else {
                            //use the moveAnimalTreatmentTasks method to finalize the change
                            schedule.moveAnimalTreatmentTasks(invalidTreat, startHourChosen);
                            break;
                        }
                    }

                }
            }
        }

        //Once invalid treatments are added, calculateEfficient is called again to optimize it
        schedule.calculateEfficient();
        String result = schedule.getFinalSchedule(); //retrieve final schedule using the method and append it to the empty StringBuilder
        sb.append(result);

        // Verify if volunteer is needed to be called
        boolean backupVolunteerFound = result.contains("backup volunteer");
        if (backupVolunteerNeeded && backupVolunteerFound) {
            sb.append("\n\nBackup volunteer is required to complete this schedule. Please confirm their availability before continuing.");
            JOptionPane.showMessageDialog(null, "Backup volunteer is required to complete this schedule. Please confirm their availability before continuing.");
        }

        //call the volunteer
        generateFile(sb.toString());
        return sb.toString();
    }


    //method used to save the generated schedule into .txt file
    private void generateFile(String schedule) {
        String fileName = "Final_Schedule" + System.currentTimeMillis() + ".txt"; // sets up filename with unique identifier of system.currentTimeMillis
        try (PrintWriter writer = new PrintWriter(new File(fileName))) { //uses PrintWriter object "writer" to into output file
            writer.write(schedule);
            JOptionPane.showMessageDialog(this, "Schedule saved", "File Saved", JOptionPane.INFORMATION_MESSAGE); //success message
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(this, "Error saving file: " + e.getMessage(), "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    //On click, it generates the schedule
    public void actionPerformed(ActionEvent e) {
        try {
            String date = dateField.getText(); //retrieves date value from previously created value
            String schedule = scheduleCalc(date, rootPaneCheckingEnabled); //calls the scheduleCalc within this class to make the schedule

            schedArea.setText(schedule); //sets text area to the generated schedule

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        // Create an instance of the EWRGUI class
        new EWRGUI();
    }

}

