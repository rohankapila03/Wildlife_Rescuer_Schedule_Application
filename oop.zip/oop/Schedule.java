package edu.ucalgary.oop;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeMap;

public class Schedule {
    //create a tree map that has a time period as the key and the list of animalTreatments as values.
    private TreeMap<Integer, ArrayList<AnimalTreatments>> animalTreatmentTasks;

    //create hashmap of the animal and the task ArrayList.
    private HashMap<String, ArrayList<Task>> otherTaskFeeding;

    //arrayList of the Cage tasks created
    private ArrayList<OtherTaskCageCleaning> otherTaskCage;

    //create a hashmap of the time and the schedule.
    private HashMap<Integer, ScheduleSlot> schedule;

    private LocalDate date;
    private String finalSchedule;
    private int day;
    private int month;
    private int year;

    //connecting the database
    private Connection dbConnection;
    private final String URL = "jdbc:mysql://localhost/EWR";
    private final String USERNAME = "user1";
    private final String PASSWORD = "ensf";

    //create an ArrayList of invalid treatments.

    private ArrayList<AnimalTreatments> invalidTreatmentsList;

    //get the index of the treatment that is invalid from treatmentList that are invalid.
    private int invalidTreatmentsListIndex;

    //return the invalid Treatments as an ArrayList<AnimalTreatments>.

    public ArrayList<AnimalTreatments> getInvalidTreatmentsList() {
        return invalidTreatmentsList;
    }

    //return the index of the invalidtreatmnenList.

    public int getInvalidTreatmentsListIndex() {
        return invalidTreatmentsListIndex;
    }

    //constructor take in the date.

    public Schedule(int day, int month, int year) throws IllegalArgumentException {
        //check if date if invalid.
        if (day < 0 || month < 0 || month > 12 || year < 0) {
            throw new IllegalArgumentException("Invalid date");
        }
        //privarte attributes are getting instantiated.
        this.day = day;
        this.month = month;
        this.year = year;
        this.date = LocalDate.of(year, month, day);
        this.animalTreatmentTasks = new TreeMap<Integer, ArrayList<AnimalTreatments>>();
        this.otherTaskCage = new ArrayList<OtherTaskCageCleaning>();
        this.finalSchedule = "";

        //using the enum get the animals and put the arraylist task in the othertaskfeeding hashmap.

        this.otherTaskFeeding = new HashMap<String, ArrayList<Task>>();
        for (AnimalEnum animal : AnimalEnum.values()) {
            otherTaskFeeding.put(animal.name().toLowerCase(), new ArrayList<Task>());
        }

        //create 24 hour schedule slot.

        this.schedule = new HashMap<Integer, ScheduleSlot>();
        for (int i = 0; i < 24; i++) {
            schedule.put(i, new ScheduleSlot());
        }
    }

    //respondsible for reading the sql database.

    public void readSql() throws SQLException {
        try {
            dbConnection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException();
        }
        //call to the create tasks function
        createTasks();
        dbConnection.close();

    }

    //create task function is responsible for accessing database and getting the data.
    private void createTasks() {
        //create an arrayList of animals from database
        ArrayList<Animal> animals = new ArrayList<Animal>();
        //create an arraylist of medicaltask from database.
        ArrayList<MedicalTask> medicalTasks = new ArrayList<MedicalTask>();

        try {
            // get the animals from db and go trough table and create an animal and put into list.
            Statement statement = dbConnection.createStatement();
            ResultSet queryResult = statement.executeQuery("SELECT * FROM ANIMALS");
            while (queryResult.next()) {

                int animalID = queryResult.getInt("AnimalID");
                String animalNickname = queryResult.getString("AnimalNickname");
                String animalSpecies = queryResult.getString("AnimalSpecies");

                String activityPattern = AnimalEnum.ActivityPatternGetter(animalSpecies);
                Animal animalObj = new Animal(animalID, animalSpecies, animalNickname, activityPattern);
                animals.add(animalObj);
            }

            //access the tasks table from the db.
            String nickname = "";
            queryResult = statement.executeQuery("SELECT * FROM TASKS");
            while (queryResult.next()) {

                int taskID = queryResult.getInt("TaskID");
                String taskDescription = queryResult.getString("Description");
                int taskDuration = queryResult.getInt("Duration");
                int taskMaxWindow = queryResult.getInt("MaxWindow");

                //get the nickname of the animal.
                for (Animal iterAnimal : animals) {
                    if (iterAnimal.animalIdGetter() == taskID) {
                        nickname = iterAnimal.nicknameGetter();
                        break;
                    }
                }
                //create a medical task and add to arraylist.
                MedicalTask medicalTaskObj = new MedicalTask(taskDescription, taskDuration, taskMaxWindow, taskID,
                        nickname);
                medicalTasks.add(medicalTaskObj);
            }

            //access the db from treatments table.
            queryResult = statement.executeQuery("SELECT * FROM TREATMENTS");
            while (queryResult.next()) {

                int animalID = queryResult.getInt("AnimalID");
                int taskID = queryResult.getInt("TaskID");
                int taskStartHour = queryResult.getInt("StartHour");

                //find the animal that is being treated.
                Animal treatmentAnimal = null;
                for (Animal iterAnimal : animals) {
                    if (iterAnimal.animalIdGetter() == animalID) {
                        treatmentAnimal = iterAnimal;
                        break;
                    }
                }

                // get the task that needs to be done
                MedicalTask treatmentTask = null;
                for (MedicalTask iterMedicalTask : medicalTasks) {
                    if (iterMedicalTask.idTaskGetter() == taskID) {
                        treatmentTask = iterMedicalTask;
                        break;
                    }
                }

                //throw exception if the treatment aninal or task is a nullpointer.
                if (treatmentAnimal == null || treatmentTask == null) {
                    throw new Exception("Animal or medical task not found");
                }


                //create a animal Treatment
                AnimalTreatments treatment = new AnimalTreatments(treatmentTask, treatmentAnimal, taskStartHour);
                //get the startHour of the treatment.
                int treatmentStartHour = treatment.startHourGetter();
                //check if time already in treemap, else create a new section for the starthour.
                if (animalTreatmentTasks.containsKey(treatmentStartHour)) {
                    animalTreatmentTasks.get(treatmentStartHour).add(treatment);
                } else {
                    ArrayList<AnimalTreatments> newTreatmentList = new ArrayList<AnimalTreatments>();
                    newTreatmentList.add(treatment);
                    animalTreatmentTasks.put(treatmentStartHour, newTreatmentList);
                }

            }

        } catch (SQLException e) {
            e.printStackTrace();

        } catch (Exception generalException) {
            generalException.printStackTrace();
        }
        //check if the animal trwatment medical task id is == 1 indicating feeding task.
        Set<Integer> orphansTaskIDs = new HashSet<Integer>();
        for (ArrayList<AnimalTreatments> iTreatmentList : animalTreatmentTasks.values()) {
            for (AnimalTreatments iTreatment : iTreatmentList) {
                if (iTreatment.MedicalTaskGetter().idTaskGetter() == 1) {
                    orphansTaskIDs.add(iTreatment.AnimalTreatedGetter().animalIdGetter());
                }
            }
        }
        //filter trough the animals from the database.
        for (Animal iterAnimal : animals) {
            //get the species and the activity type.
            String animalSpecies = iterAnimal.speciesGetter();
            String activityPattern = iterAnimal.ActivityPatternGetter();

            //get the time of the cleaning cage from enum.
            int duration = AnimalEnum.CleaningCageDurationGetter(animalSpecies);
            OtherTaskCageCleaning cageCleaning = null;
            try {
                //create a cage cleaning other task.
                cageCleaning = new OtherTaskCageCleaning("Cage Cleaning", duration, -1,
                        iterAnimal.nicknameGetter());

                this.otherTaskCage.add(cageCleaning);
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            }

            if (orphansTaskIDs.contains(iterAnimal.animalIdGetter())) {
                continue;
            }

            OtherTaskFeedingTask feeding = null;
            int maxWindow = -1;

            //create the feeding task by getting the maxwindow.
            int feedingDuration = AnimalEnum.FeedingPrepDurationGetter(animalSpecies);
            feedingDuration += AnimalEnum.FeedingDurationGetter(animalSpecies);

            if (activityPattern.equalsIgnoreCase("nocturnal")) {
                maxWindow = 3;
            } else if (activityPattern.equalsIgnoreCase("diurnal")) {
                maxWindow = 11;
            } else if (activityPattern.equalsIgnoreCase("crepuscular")) {
                maxWindow = 22;
            }

            try {
                feeding = new OtherTaskFeedingTask("Feeding", feedingDuration,
                        maxWindow, iterAnimal.nicknameGetter(), iterAnimal.speciesGetter());
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            }
            //add the feeding task to other task feeding.
            this.otherTaskFeeding.get(iterAnimal.speciesGetter()).add(feeding);

        }

    }

    //creates the schedule and calls a function that makes sure the schedule is efficient.
    public void calculateEfficient() {
        String result = this.date.toString() +"schedule \n\n";
        //get the schedule slot for the hour
        for (int startHour : schedule.keySet()) {
            ScheduleSlot timeslot = schedule.get(startHour);

            if (timeslot.taskGetter().isEmpty()) {
                continue;
            }
            //create the format of the schedule
            result += startHour + ":00";

            // check if a backupVolunteer needed sand add to the result.
            if (timeslot.backupVolunteerGetter()) {
                result += " [+ backup volunteer]\n";
            } else {
                result += "\n";
            }
            //format the task inside the scheduleslot.
            result += tasksFormat(timeslot);

            result += "\n";

        }
        //gets the final schedule
        this.finalSchedule = result;

    }


    //this function is responsible for creating an optimal schedule.
    public void makeEfficientSchedule() throws IllegalArgumentException {
        //go trough the starthour of animalTreatmentTasks.
        for (int startHour : animalTreatmentTasks.keySet()) {
            //gets the animal treatments in each hour
            ArrayList<AnimalTreatments> treatments = animalTreatmentTasks.get(startHour);
            int nextTime = startHour;
            int iCurrentTreat = 0;
            int count = 0;
            //gets schedule slot.
            ScheduleSlot timeslot = schedule.get(startHour);
            ScheduleSlot nextTimeslot = schedule.get(nextTime);

            for (AnimalTreatments iterTreatment : treatments) {
                //calculate duration of medical task
                int duration = iterTreatment.MedicalTaskGetter().durationGetter();

                int timeDifference = nextTimeslot.timeAvaliableGetter() - duration;
                //check id duration of task fit into schedule slot
                if (timeDifference < 0) {
                    if (count == 1) {
                        //all remaining task become invalid on last iterations.
                        this.invalidTreatmentsList = treatments;
                        this.invalidTreatmentsListIndex = iCurrentTreat;
                        clearSchedule();
                        throw new IllegalArgumentException(
                                "There are too many medical tasks to fit across two hours at "
                                        + (startHour + count) + ":00 . Please move some tasks.");
                    } else {
                        count++;
                    }

                    timeslot.taskAdder(iterTreatment.MedicalTaskGetter());

                    nextTimeslot.timeAvailableSetter(0);
                    nextTimeslot.backupVolunteerSetter(true);

                    nextTime++;
                    nextTimeslot = schedule.get(nextTime);
                    try {
                        nextTimeslot.timeAvailableAdder(timeDifference);
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    }
                } else {
                    try {
                        timeslot.taskAdder(iterTreatment.MedicalTaskGetter());
                        nextTimeslot.timeAvailableAdder(-duration);
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    }

                }
                iCurrentTreat++;
            }
        }

        addOtherTaskFeeding();

    }

    //adds the feeding and cage cleaning task to schedule.
    private void addOtherTaskFeeding() throws IllegalArgumentException {
        //iterate trough other task feeding.
        for (String animal : this.otherTaskFeeding.keySet()) {
            ArrayList<Task> otherTaskFeedingList = this.otherTaskFeeding.get(animal);
            if (otherTaskFeedingList.isEmpty()) {
                continue;
            }
            //find maximum window.
            int maxWindow = otherTaskFeedingList.get(0).MaxWindowGetter();
            int startHour = maxWindow - 3;
            //get schedule slot for start hour.
            ScheduleSlot timeslot = schedule.get(startHour);

            int timeRemaining = timeslot.timeAvaliableGetter();
            int feedingDuration = AnimalEnum.FeedingDurationGetter(animal);
            int prepDuration = AnimalEnum.FeedingPrepDurationGetter(animal);
            int minTimeFeeding = prepDuration + feedingDuration;
            //check if enough time for feeding in times slot move onto next if there isnt.
            while (startHour < maxWindow) {
                if (timeRemaining >= minTimeFeeding) {
                    int tasksToGroup = (timeRemaining - prepDuration) / feedingDuration;
                    timeRemaining -= (prepDuration);
                    for (int i = 0; i < tasksToGroup; i++) {
                        timeslot.taskAdder(otherTaskFeedingList.get(0));
                        otherTaskFeedingList.remove(0);
                        timeRemaining -= feedingDuration;
                        if (otherTaskFeedingList.isEmpty()) {
                            break;
                        }
                    }
                    timeslot.timeAvailableSetter(timeRemaining);
                    if (otherTaskFeedingList.isEmpty()) {
                        break;
                    }
                }

                startHour++;
                if (startHour == maxWindow) {
                    throw new IllegalArgumentException("There isn't room for all the feeding tasks");
                }
                timeslot = schedule.get(startHour);
                timeRemaining = timeslot.timeAvaliableGetter();
            }
        }
        int startHour = 0;
        //search for available hour and add task and update remaining time.
        for (OtherTaskCageCleaning cageTask : this.otherTaskCage) {
            // int timeTaken = cageTask
            while (startHour < 24) {

                ScheduleSlot timeslot = schedule.get(startHour);
                if (timeslot.timeAvaliableGetter() >= cageTask.durationGetter()) {
                    timeslot.taskAdder(cageTask);
                    try {
                        timeslot.timeAvailableAdder(-cageTask.durationGetter());
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    }
                    break;
                }
                startHour++;
            }
        }
    }

    //
    public void moveAnimalTreatmentTasks(AnimalTreatments treatment, int startHour) {
        int oldStartHour = treatment.startHourGetter();
        animalTreatmentTasks.get(oldStartHour).remove(treatment);

        treatment.startHourSetter(startHour);
        animalTreatmentTasks.get(startHour).add(treatment);
    }

    //add a task to schedule
    public void addTask(Task task, int startHour) {
        schedule.get(startHour).taskAdder(task);
    }

    //addtreatment at starthour
    public void addTreatment(AnimalTreatments treatment, int startHour) {
        animalTreatmentTasks.get(startHour).add(treatment);
    }

    //clear the schedule.
    public void clearSchedule() {
        this.schedule = new HashMap<Integer, ScheduleSlot>();
        for (int i = 0; i < 24; i++) {
            schedule.put(i, new ScheduleSlot());
        }
    }

    //get the final schedule
    public String getFinalSchedule() {
        return this.finalSchedule;
    }

    //get the treated animal task treemap

    public TreeMap<Integer, ArrayList<AnimalTreatments>> getanimalTreatmentTasks() {
        return this.animalTreatmentTasks;
    }

    //get the day.
    public int getDay() {
        return this.day;
    }

    //get the month
    public int getMonth() {
        return this.month;
    }

    //get the year

    public int getYear() {
        return this.year;
    }

    //return thr treatments list
    public ArrayList<AnimalTreatments> getTreatmentList() {
        ArrayList<AnimalTreatments> allTreatments = new ArrayList<>();
        for (ArrayList<AnimalTreatments> iterTreatmentList : animalTreatmentTasks.values()) {
            for (AnimalTreatments iterTreatment : iterTreatmentList) {
                allTreatments.add(iterTreatment);
            }
        }
        return allTreatments;
    }

    //format the tasks inside the scheduled slot.
    private String tasksFormat(ScheduleSlot timeslot) {
        HashMap<String, ArrayList<Object>> feedingCount = new HashMap<String, ArrayList<Object>>();
        String result = "";
        String cageResult = "";
        //iterate trough task in time slot.
        for (Task task : timeslot.taskGetter()) {
            //CHECK IF TASK in other task feeding task.
            if (task instanceof OtherTaskFeedingTask) {
                //get the species
                String species = ((OtherTaskFeedingTask) task).animalSpeciesGetter();

                ArrayList<Object> feedingInfo;
                //check if species in feeding count
                if (feedingCount.containsKey(species)) {
                    feedingInfo = feedingCount.get(((OtherTaskFeedingTask) task).animalSpeciesGetter());
                    int count = (Integer) feedingInfo.get(0);
                    count++;
                    feedingInfo.set(0, count);
                    String nicknames = (String) feedingInfo.get(1);
                    feedingInfo.remove(1);
                    feedingInfo.add(nicknames + ", " + task.nicknameGetter());
                } else {
                    feedingInfo = new ArrayList<Object>();
                    feedingInfo.add(1);
                    feedingInfo.add(task.nicknameGetter());
                }
                feedingCount.put(species, feedingInfo);
                //add a medical task.
            } else if (task instanceof MedicalTask) {

                result += "* " + task.descriptionGetter() + " (" + task.nicknameGetter() + ")\n";

                //add cleaning task
            } else if (task instanceof OtherTaskCageCleaning) {

                cageResult += "* " + task.descriptionGetter() + " (" + task.nicknameGetter() + ")\n";
            } else {
                System.out.println("Error: Unknown task type");
            }
        }

        for (String animalSpecies : feedingCount.keySet()) {
            ArrayList<Object> feedingInfo = feedingCount.get(animalSpecies);
            int count = (Integer) feedingInfo.get(0);
            String nicknames = (String) feedingInfo.get(1);
            result += "* Feed : " + animalSpecies + " (" + count + "- " + nicknames + ")\n";
        }

        result += cageResult;
        return result;
    }

    //return date.
    public LocalDate getDate() {
        return this.date;
    }
}

